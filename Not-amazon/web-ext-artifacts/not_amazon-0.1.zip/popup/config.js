function saveOptions(e) {
    e.preventDefault();
    let selected = 'ddg';
    options = ['ddg', 'google']
    for (let i = 0; i < options.length; i ++) {
        if (document.getElementById(options[i]).checked) {
            selected = options[i]
        }
    }
    browser.storage.sync.set({
        search_engine: selected
    });
}

function restoreOptions() {

    function setCurrentChoice(result) {
        document.getElementById(result.search_engine || "ddg").click();
    }

    function onError(error) {
        console.log(`Error: ${error}`);
        window.alert(error);
    }

    //document.getElementById('asdf').innerHTML = 'goodbye world';
    let getting = browser.storage.sync.get("search_engine");
    getting.then(setCurrentChoice, onError);
}

document.addEventListener("DOMContentLoaded", restoreOptions);
document.querySelector("form").addEventListener("submit", saveOptions);
